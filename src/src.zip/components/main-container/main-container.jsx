// import React from "react";

// import "./main-container.css";
// import Artists from "../artists/artists";
// import Products from "../products/products";

// const MainContainer = () => {
//   return (
//     <div>
//       <div className="row-of-artists">
//         <Artists />
//       </div>
//       <div className="grid-of-products">
//         <Products />
//       </div>
//     </div>
//   );
// };

// export default MainContainer;
