import React from 'react';
import ListOfProducts from "../list-of-products/ListOfProducts"

const Shop = () => {
    return (
      <div className="main-container">
        <ListOfProducts />
      </div>
    );
}
 
export default Shop;