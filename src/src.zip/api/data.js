const dataArtists = [
  {
    id: 1,
    name: "Frida Kahlo",
    imgUrl:
      "https://aventurasnahistoria.uol.com.br/media/_versions/fridahqudnna_widelg.jpg",
  },
  {
    id: 2,
    name: "Van Gogh",
    imgUrl:
      "https://santhatela.com.br/wp-content/uploads/2017/05/blog_van_gogh.jpg",
  },
  {
    id: 3,
    name: "O'Keeffe",
    imgUrl:
      "https://www.biography.com/.image/t_share/MTE4MDAzNDEwNjQ1Nzc5OTgy/georgia-okeeffe-9427684-1-402.jpg",
  },
  {
    id: 4,
    name: "ringgold",
    imgUrl:
      "https://amenteemaravilhosa.com.br/wp-content/uploads/2019/09/faith-ringgold-1024x644.png",
  },
  {
    id: 5,
    name: "Ansel Adams",
    imgUrl:
      "https://calisphere.org/clip/500x500/7016bdc9d15136b998241274a6b0fa61",
  },
  {
    id: 6,
    name: "Eve Arnold",
    imgUrl:
      "https://blog.emania.com.br/wp-content/uploads/2017/03/Eve-Arnold-1200x746.png",
  },
  {
    id: 7,
    name: "warhol",
    imgUrl:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRyd_Iw1bEQNT4vBvitylC8sPC6FORHr02QkA&usqp=CAU",
  },
  {
    id: 8,
    name: "Leibovitz",
    imgUrl:
      "https://secureservercdn.net/198.71.233.51/xz7.4b6.myftpupload.com/wp-content/uploads/2017/12/iphoto-curso-online-com-annie-leibovitz-990x554.jpg",
  },
  {
    id: 9,
    name: "Brassaï",
    imgUrl:
      "https://d16kd6gzalkogb.cloudfront.net/artist_images/Brassa%C3%AF-profile.jpg",
  },
  {
    id: 10,
    name: "Kara Walker",
    imgUrl:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQXWllkWDyoEY-DuHG_9pM_ZujNubUeVLjfSA&usqp=CAU",
  },
  {
    id: 11,
    name: "bourgeois",
    imgUrl:
      "https://www.cdlcampos.org.br/thumb.php?arquivo=images/noticias/foto_01_06_2010_1275399215.jpeg&largura=820&altura=480&crop=fill",
  },
  {
    id: 12,
    name: "Eva Hesse",
    imgUrl:
      "https://www.artnews.com/wp-content/uploads/2017/08/img-hesse-1105028922273.jpg?w=579&h=383&crop=1",
  },
  {
    id: 13,
    name: "Ai Weiwei",
    imgUrl:
      "https://media.gazetadopovo.com.br/haus/2019/05/sementes-girassol-mon-ai-weiwei-haus-1024x695-b8cecbf0.jpg",
  },
];

export default dataArtists;
