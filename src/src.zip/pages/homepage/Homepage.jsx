import React from "react";


import ListOfProducts from "../../components/list-of-products/ListOfProducts";

const Homepage = () => {
  return (
    <div>
     
      <div className="main-container">
        <ListOfProducts />
      </div>
    </div>
  );
};

export default Homepage;
