import React from "react";

import Shop from "../../components/shop/Shop";

const ShopPage = () => {
  return (
    <div>
      <Shop />
    </div>
  );
};

export default ShopPage;
