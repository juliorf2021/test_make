import React from 'react';

import SignIn from "../../components/sign-in/SignIn";

const SignInPage = () => {
    return (<div>
        <SignIn />
    </div> );
}
 
export default SignInPage;