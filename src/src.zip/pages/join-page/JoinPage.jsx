import React from "react";

import Join from "../../components/join/Join";

const JoinPage = () => {
  return (
    <div>
      <Join />
    </div>
  );
};

export default JoinPage;
